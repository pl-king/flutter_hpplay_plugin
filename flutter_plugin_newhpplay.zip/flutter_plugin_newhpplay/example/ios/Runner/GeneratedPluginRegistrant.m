//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_plugin_newhpplay/FlutterPluginNewhpplayPlugin.h>)
#import <flutter_plugin_newhpplay/FlutterPluginNewhpplayPlugin.h>
#else
@import flutter_plugin_newhpplay;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterPluginNewhpplayPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterPluginNewhpplayPlugin"]];
}

@end
