#import <Flutter/Flutter.h>

@interface FlutterPluginNewhpplayPlugin : NSObject<FlutterPlugin>
@end
